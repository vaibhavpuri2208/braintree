Poker::Application.routes.draw do

get "/poker", :controller => "Poker", :action => "dumb_poker_player"



end
