# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Poker::Application.config.secret_token = '47454344cc6f90fb9edd80f8531559b831215059b811616caf4129655dd9c2014751247e6ba07a416571a48d4063c90d496f970ec39bc12c4c73e3ffbb78ca73'
